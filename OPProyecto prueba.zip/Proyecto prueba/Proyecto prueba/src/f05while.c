#include <stdio.h>

int main() {
    int n;
    printf("Ingrese la altura del triangulo: ");
    scanf("%d", &n);
    printf("\n");

    int i = 1;
    while (i <= n) {
        // Espacios
        int j = 1;
        while (j <= n - i) {
            printf(" ");
            j++;
        }

        // Asteriscos
        int k = 1;
        while (k <= (2 * i - 1)) {
            printf("*");
            k++;
        }

        printf("\n");
        i++;
    }

    getchar();
    getchar();
    return 0;
}