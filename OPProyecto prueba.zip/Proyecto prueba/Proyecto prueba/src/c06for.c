#include <stdio.h>

int main() {
    char frase[1000], invertida[1000];
    int longitud = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    // Calcular longitud sin contar '\n'
    for (int i = 0; frase[i] != '\0' && frase[i] != '\n'; i++) {
        longitud++;
    }

    int j = 0;
    for (int i = longitud - 1; i >= 0; i--) {
        char c = frase[i];

        // Verificar si es vocal minúscula o mayúscula
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
            c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
            // Convertir a minúscula si está en mayúscula
            if (c >= 'A' && c <= 'Z') {
                c += 32;
            }
        }
        // Si es letra y no es vocal, convertir a mayúscula
        else if (c >= 'a' && c <= 'z') {
            c -= 32;
        }

        invertida[j++] = c;
    }

    invertida[j] = '\0';

    printf("Salida: %s\n", invertida);

    while (getchar() != '\n'); // limpiar buffer
    getchar(); // esperar Enter

    return 0;
}