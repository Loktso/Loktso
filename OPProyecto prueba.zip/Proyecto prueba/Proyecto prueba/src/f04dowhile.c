#include <stdio.h>

int main() {
    int n;
    printf("Ingrese el tamano del triangulo: ");
    scanf("%d", &n);
    printf("\n");

    int i = 1;
    do {
        // Espacios (solo si se necesitan)
        if (n - i > 0) {
            int j = 1;
            do {
                printf("  ");
                j++;
            } while (j <= n - i);
        }

        // Asteriscos
        int k = 1;
        do {
            printf("* ");
            k++;
        } while (k <= i);

        printf("\n");
        i++;
    } while (i <= n);

    getchar();
    getchar();
    return 0;
}