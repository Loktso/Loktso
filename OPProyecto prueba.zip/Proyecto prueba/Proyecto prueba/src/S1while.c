#include <stdio.h>



int main() {
    int n, a=0, b=1, c, i=0;
    printf("ingrese cuantos numeros de la serie desea ver");
    scanf("%d", &n);
    while (i<n)
    {
        printf("%d ", a);
        c=a+b;
        a=b;
        b=c;
        i++;
    }
        getchar();
    
    getchar(); 
    return 0;
}