#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char frase[200];
    printf("Ingresa una frase: ");

    if (fgets(frase, sizeof(frase), stdin) == NULL) {
        printf("Error al leer la entrada.\n");
        return 1;
    }

    frase[strcspn(frase, "\n")] = 0;

    int i = 0;

    if (frase[0] != '\0') {
        do {
            if (frase[i] == ' ') {
                putchar(' ');
            } else {
                if (i % 2 == 0)
                    putchar(toupper(frase[i]));
                else
                    putchar(tolower(frase[i]));
            }
            i++;
        } while (frase[i] != '\0');
    }

    printf("\n");
    getchar(); // Espera una tecla antes de cerrar (opcional)
    return 0;
}