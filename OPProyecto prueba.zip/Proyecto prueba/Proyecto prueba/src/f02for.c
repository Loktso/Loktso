#include <stdio.h>

int main() {
    int n;
    printf("Por favor ingrese el tamano para la figurita: ");
    scanf("%d", &n);
    printf("\n");

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i == 0 || i == n - 1 || j == 0 || j == n - 1) {
                // Alternar entre * y + usando la suma de índices
                if ((i + j) % 2 == 0) {
                    printf("* ");
                } else {
                    printf("+ ");
                }
            } else {
                printf("  ");
            }
        }
        printf("\n");
    }

    getchar();
    getchar();
    return 0;
}