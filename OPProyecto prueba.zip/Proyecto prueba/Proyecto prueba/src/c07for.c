#include <stdio.h>

int main() {
    char frase[1000], resultado[1000];
    int j = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    for (int i = 0; frase[i] != '\0'; i++) {
        char c = frase[i];

        // Saltar 'j' o 'J'
        if (c == 'j' || c == 'J') {
            continue;
        }

        // Convertir a mayúscula si es minúscula
        if (c >= 'a' && c <= 'z') {
            c -= 32;
        }

        resultado[j++] = c;
    }

    resultado[j] = '\0';

    printf("Salida: %s\n", resultado);

    while (getchar() != '\n'); // limpiar buffer (por si quedó algo)
    getchar(); // esperar Enter

    return 0;
}