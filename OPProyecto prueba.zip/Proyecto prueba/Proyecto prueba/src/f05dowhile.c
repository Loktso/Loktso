#include <stdio.h>

int main() {
    int n;
    printf("Ingrese la altura del triangulo: ");
    scanf("%d", &n);
    printf("\n");

    int i = 1;
    do {
        // Espacios
        int j = 1;
        while (j <= n - i) {
            printf(" ");
            j++;
        }

        // Asteriscos
        int k = 1;
        do {
            printf("*");
            k++;
        } while (k <= (2 * i - 1));

        printf("\n");
        i++;
    } while (i <= n);

    getchar();
    getchar();
    return 0;
}