#include <stdio.h>

int main() {
    int n;
    printf("Ingrese la altura del triangulo: ");
    scanf("%d", &n);
    printf("\n");

    int i = n;
    do {
        // Espacios a la izquierda
        int j = 1;
        while (j <= n - i) {
            printf(" ");
            j++;
        }

        // Asteriscos
        int k = 1;
        do {
            printf("*");
            k++;
        } while (k <= (2 * i - 1));

        printf("\n");
        i--;
    } while (i >= 1);

    getchar();
    getchar();
    return 0;
}