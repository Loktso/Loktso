#include <stdio.h>

int main() {
    int n;
    printf("Por favor ingrese el tamano para la figurita: ");
    scanf("%d", &n);
    printf("\n");

    int i = 0;
    while (i < n) {
        int j = 0;
        while (j < n) {
            if (i == 0 || i == n - 1 || j == 0 || j == n - 1) {
                // Alternar entre * y + según la posición (i + j)
                if ((i + j) % 2 == 0) {
                    printf("* ");
                } else {
                    printf("+ ");
                }
            } else {
                printf("  ");
            }
            j++;
        }
        printf("\n");
        i++;
    }

    getchar();
    getchar();
    return 0;
}