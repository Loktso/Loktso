#include <stdio.h>

int main() {
    int n;
    printf("Ingrese el tamano del triangulo: ");
    scanf("%d", &n);
    printf("\n");

    int i = 1;
    while (i <= n) {
        int j = 1;
        while (j <= n - i) {
            printf("  ");
            j++;
        }

        int k = 1;
        while (k <= i) {
            printf("* ");
            k++;
        }

        printf("\n");
        i++;
    }

    getchar();
    getchar();
    return 0;
}