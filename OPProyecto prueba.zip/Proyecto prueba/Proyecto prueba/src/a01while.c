#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_WORDS 10
#define BAR_LENGTH 15

int main() {
    char nombre[200];
    char porcentaje_str[200];
    char *palabras[MAX_WORDS];
    int porcentajes[MAX_WORDS];
    int num_palabras = 0, num_porcentajes = 0;

    // Leer nombre completo
    printf("Ingrese su nombre completo:\n");
    fgets(nombre, sizeof(nombre), stdin);
    nombre[strcspn(nombre, "\n")] = '\0';

    // Separar palabras con while
    char *token = strtok(nombre, " ");
    while (token != NULL && num_palabras < MAX_WORDS) {
        palabras[num_palabras++] = token;
        token = strtok(NULL, " ");
    }

    // Leer los porcentajes
    printf("Ingrese el porcentaje de carga (uno por palabra, separados por espacio):\n");
    fgets(porcentaje_str, sizeof(porcentaje_str), stdin);
    porcentaje_str[strcspn(porcentaje_str, "\n")] = '\0';

    // Separar porcentajes con while
    token = strtok(porcentaje_str, " ");
    while (token != NULL && num_porcentajes < MAX_WORDS) {
        porcentajes[num_porcentajes++] = atoi(token);
        token = strtok(NULL, " ");
    }

    // Validar cantidad
    if (num_porcentajes != num_palabras) {
        printf("\n❌ Error: Ingresaste %d palabras y %d porcentajes.\n", num_palabras, num_porcentajes);
        return 1;
    }

    // Mostrar nombre
    printf("\nNombre ingresado: ");
    int i = 0;
    while (i < num_palabras) {
        printf("%s ", palabras[i++]);
    }
    printf("\n\n");

    // Mostrar barras
    i = 0;
    while (i < num_palabras) {
        int porcentaje = porcentajes[i];
        int barra = (porcentaje * BAR_LENGTH) / 100;

        printf("[");
        int j = 0;
        while (j < BAR_LENGTH) {
            if (j < barra - 1) printf("=");
            else if (j == barra - 1) printf(">");
            else printf(" ");
            j++;
        }
        printf("] %3d%% ", porcentaje);

        int mostrar = (strlen(palabras[i]) * porcentaje) / 100;
        j = 0;
        while (j < mostrar) {
            printf("%c", palabras[i][j]);
            j++;
        }
        printf("\n");
        i++;
    }

    // Esperar enter para cerrar
    printf("\nPresiona Enter para salir...");
    getchar();
    getchar();

    return 0;
}