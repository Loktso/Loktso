#include <stdio.h>



int main() {
    int n, a=0, b=1, c, i=0;
    printf("ingrese cuantos numeros de la serie desea ver");
    scanf("%d", &n);

    if (n>0)
    {
        do
        {
            printf("%d ", a);
            c=a+b;
            a=b;
            b=c;
            i++;
        } while (i<n);
        
    }
    

        getchar();
    
    getchar(); 
    return 0;
}