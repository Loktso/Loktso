#include <stdio.h>

int main() {
    char frase[1000], invertida[1000];
    int longitud = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    // Calcular la longitud real sin contar el '\n'
    while (frase[longitud] != '\0' && frase[longitud] != '\n') {
        longitud++;
    }

    int j = 0;
    for (int i = longitud - 1; i >= 0; i--) {
        char c = frase[i];

        // Convertir vocales a mayúsculas
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            c -= 32; // Convierte a mayúscula (ASCII)
        }

        invertida[j++] = c;
    }

    invertida[j] = '\0';

    printf("Salida: %s\n", invertida);

    while (getchar() != '\n'); // Limpiar buffer
    getchar(); // Esperar Enter

    return 0;
}