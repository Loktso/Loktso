#include <stdio.h>

int main() {
    char frase[1000], invertida[1000];
    int longitud = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    // Obtener longitud real (sin '\n')
    while (frase[longitud] != '\0' && frase[longitud] != '\n') {
        longitud++;
    }

    int i = longitud - 1;
    int j = 0;

    if (longitud > 0) {
        do {
            char c = frase[i];

            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                c -= 32;
            }

            invertida[j++] = c;
            i--;
        } while (i >= 0);
    }

    invertida[j] = '\0';

    printf("Salida: %s\n", invertida);

    while (getchar() != '\n'); // limpiar buffer
    getchar();

    return 0;
}