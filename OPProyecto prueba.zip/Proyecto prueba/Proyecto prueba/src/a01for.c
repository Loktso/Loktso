#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_WORDS 10
#define BAR_LENGTH 15

int main() {
    char nombre[200];
    char porcentaje_str[200];
    char *palabras[MAX_WORDS];
    int porcentajes[MAX_WORDS];
    int num_palabras = 0, num_porcentajes = 0;

    // Leer nombre completo
    printf("Ingrese su nombre completo:\n");
    fgets(nombre, sizeof(nombre), stdin);
    nombre[strcspn(nombre, "\n")] = '\0';

    // Separar nombre en palabras
    char *token = strtok(nombre, " ");
    for (; token != NULL && num_palabras < MAX_WORDS; num_palabras++) {
        palabras[num_palabras] = token;
        token = strtok(NULL, " ");
    }

    // Leer los porcentajes como cadena
    printf("Ingrese el porcentaje de carga (uno por palabra, separados por espacio):\n");
    fgets(porcentaje_str, sizeof(porcentaje_str), stdin);
    porcentaje_str[strcspn(porcentaje_str, "\n")] = '\0';

    // Separar porcentajes
    token = strtok(porcentaje_str, " ");
    for (; token != NULL && num_porcentajes < MAX_WORDS; num_porcentajes++) {
        porcentajes[num_porcentajes] = atoi(token);
        token = strtok(NULL, " ");
    }

    // Validar que el número de porcentajes coincida
    if (num_porcentajes != num_palabras) {
        printf("\n❌ Error: Ingresaste %d palabras y %d porcentajes.\n", num_palabras, num_porcentajes);
        printf("Por favor asegúrate de ingresar un porcentaje para cada palabra.\n");
        return 1;
    }

    // Imprimir nombre completo
    printf("\nNombre ingresado: ");
    for (int i = 0; i < num_palabras; i++) {
        printf("%s ", palabras[i]);
    }
    printf("\n\n");

    // Imprimir barras de carga
    for (int i = 0; i < num_palabras; i++) {
        int porcentaje = porcentajes[i];
        int barra = (porcentaje * BAR_LENGTH) / 100;

        printf("[");
        for (int j = 0; j < BAR_LENGTH; j++) {
            if (j < barra - 1)
                printf("=");
            else if (j == barra - 1)
                printf(">");
            else
                printf(" ");
        }
        printf("] %3d%% ", porcentaje);

        int mostrar = (strlen(palabras[i]) * porcentaje) / 100;
        for (int j = 0; j < mostrar; j++) {
            printf("%c", palabras[i][j]);
        }

        printf("\n");
    }

    return 0;
}