#include <stdio.h>

int main() {
    char frase[1000];
    int letras = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    for (int i = 0; frase[i] != '\0'; i++) {
        char c = frase[i];
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
            letras++;
        }
    }

    printf("La frase tiene %d letras.\n", letras);

    while (getchar() != '\n'); // Limpiar buffer si quedó algo
    getchar(); // Esperar Enter

    return 0;
}