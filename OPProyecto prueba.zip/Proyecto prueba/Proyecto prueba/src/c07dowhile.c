#include <stdio.h>

int main() {
    char frase[1000], resultado[1000];
    int i = 0, j = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    if (frase[0] != '\0') {
        do {
            char c = frase[i];

            if (c != 'j' && c != 'J') {
                if (c >= 'a' && c <= 'z') {
                    c -= 32;
                }
                resultado[j++] = c;
            }
            i++;
        } while (frase[i] != '\0');
    }

    resultado[j] = '\0';

    printf("Salida: %s\n", resultado);

    while (getchar() != '\n'); // limpiar buffer
    getchar();

    return 0;
}