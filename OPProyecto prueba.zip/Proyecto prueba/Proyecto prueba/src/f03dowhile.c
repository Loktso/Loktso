#include <stdio.h>

int main() {
    int n;
    printf("Ingrese el tamano del triangulo: ");
    scanf("%d", &n);
    printf("\n");

    int i = 1;
    do {
        int j = 1;
        do {
            printf("* ");
            j++;
        } while (j <= i);
        printf("\n");
        i++;
    } while (i <= n);

    getchar();
    getchar();
    return 0;
}