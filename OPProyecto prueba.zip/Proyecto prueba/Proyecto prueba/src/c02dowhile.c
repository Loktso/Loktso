#include <stdio.h>

int main() {
    char frase[1000];
    int letras = 0, i = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    if (frase[0] != '\0') {
        do {
            char c = frase[i];
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
                letras++;
            }
            i++;
        } while (frase[i] != '\0');
    }

    printf("La frase tiene %d letras.\n", letras);

    while (getchar() != '\n'); // Limpiar buffer
    getchar(); // Esperar Enter

    return 0;
}