#include <stdio.h>

int main() {
    char frase[1000], resultado[1000], vocal;
    int i, j = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    printf("Ingrese una vocal: ");
    scanf(" %c", &vocal);  // espacio antes del %c para ignorar saltos de línea

    // Recorremos la frase original
    for (i = 0; frase[i] != '\0'; i++) {
        char c = frase[i];

        // Comparar evitando la vocal (tanto minúscula como mayúscula)
        if (c != vocal && c != (vocal >= 'a' ? vocal - 32 : vocal + 32)) {
            resultado[j++] = c;
        }
    }

    resultado[j] = '\0'; // Finaliza la nueva cadena

    printf("Salida '%c': %s\n", vocal, resultado);

    while (getchar() != '\n'); // Limpiar buffer
    getchar(); // Esperar Enter

    return 0;
}