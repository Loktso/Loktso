#include <stdio.h>

int main() {
    char frase[1000], resultado[1000], vocal;
    int i = 0, j = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    printf("Ingrese una vocal: ");
    scanf(" %c", &vocal);  // el espacio antes de %c evita problemas con '\n'

    while (frase[i] != '\0') {
        char c = frase[i];
        // Comparar la letra con la vocal (minúscula o mayúscula)
        if (c != vocal && c != (vocal >= 'a' ? vocal - 32 : vocal + 32)) {
            resultado[j++] = c;
        }
        i++;
    }

    resultado[j] = '\0';  // Fin de cadena

    printf("Salida '%c': %s\n", vocal, resultado);

    while (getchar() != '\n');  // Limpiar buffer si quedó algo
    getchar();  // Esperar Enter

    return 0;
}