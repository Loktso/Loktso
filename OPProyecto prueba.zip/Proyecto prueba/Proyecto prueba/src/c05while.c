#include <stdio.h>

int main() {
    char frase[1000], invertida[1000];
    int longitud = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    // Obtener longitud de la frase (sin contar el salto de línea)
    while (frase[longitud] != '\0' && frase[longitud] != '\n') {
        longitud++;
    }

    int i = longitud - 1;
    int j = 0;
    while (i >= 0) {
        char c = frase[i];

        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            c -= 32; // Convertir a mayúscula
        }

        invertida[j++] = c;
        i--;
    }

    invertida[j] = '\0';

    printf("Salida: %s\n", invertida);

    while (getchar() != '\n'); // limpiar buffer
    getchar();

    return 0;
}
