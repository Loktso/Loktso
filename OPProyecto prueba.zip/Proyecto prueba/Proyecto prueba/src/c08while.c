#include <stdio.h>

#include <stdio.h>
#include <string.h>
#include <ctype.h>

void toLowerStr(char* str) {
    for (int i = 0; str[i]; i++) {
        if (str[i] >= 'A' && str[i] <= 'Z')
            str[i] += 32;
    }
}

void sortString(char* str) {
    int len = strlen(str);
    for (int i = 0; i < len - 1; i++) {
        for (int j = i + 1; j < len; j++) {
            if (str[i] > str[j]) {
                char tmp = str[i];
                str[i] = str[j];
                str[j] = tmp;
            }
        }
    }
}

int sonAnagramas(const char* s1, const char* s2) {
    char a[100], b[100];
    strcpy(a, s1);
    strcpy(b, s2);
    toLowerStr(a);
    toLowerStr(b);
    sortString(a);
    sortString(b);
    return strcmp(a, b) == 0;
}

int esAnagramaValido(char opciones[][100], int nOpciones, const char* intento) {
    for (int i = 0; i < nOpciones; i++) {
        if (sonAnagramas(opciones[i], intento))
            return 1;
    }
    return 0;
}

int main() {
    const char* palabras[5] = {"ratas", "armas", "letras", "ramas", "moras"};

    char opciones[5][5][100] = {
        {"sarta", "astar", "tasar", "rasta", "sarta"},
        {"asmar", "marsa", "maras", "samar", "masar"},
        {"lastre", "alertas", "estral", "artes", "artels"},
        {"maras", "samara", "masar", "asmar", "marsa"},
        {"ramos", "somos", "amos", "ramso", "osmar"}};

    int p = 0;
    const int maxIntentos = 3;
    char intento[100];

    while (p < 5) {
        printf("Ingrese un anagrama de la palabra \"%s\":\n", palabras[p]);

        int intentos = 0;
        int acierto = 0;

        while (intentos < maxIntentos) {
            printf("Intento %d: ", intentos + 1);

            if (fgets(intento, sizeof(intento), stdin) == NULL) {
                printf("\nEntrada finalizada inesperadamente.\n");
                return 1;
            }

            intento[strcspn(intento, "\n")] = 0;

            if (strlen(intento) == 0) {
                printf("Por favor ingrese un intento valido.\n");
                continue;
            }

            if (esAnagramaValido(opciones[p], 5, intento)) {
                printf("Correcto!\n\n");
                acierto = 1;
                break;
            } else {
                printf("Incorrecto.\n");
            }

            intentos++;
        }

        if (!acierto) {
            printf("Has agotado los intentos.\n");
            printf("Las respuestas correctas pueden ser:\n");
            for (int i = 0; i < 5; i++) {
                printf("- %s\n", opciones[p][i]);
            }
            printf("\n");
        }

        p++;
    }

    printf("Juego terminado.");
    getchar();

    return 0;
}