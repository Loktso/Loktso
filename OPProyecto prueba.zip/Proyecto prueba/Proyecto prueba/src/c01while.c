#include <stdio.h>

int main() {
    char frase[1000];
    int vocales = 0, i = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    while (frase[i] != '\0') {
        char c = frase[i];
        if (c == 'a' || c == 'A' ||
            c == 'e' || c == 'E' ||
            c == 'i' || c == 'I' ||
            c == 'o' || c == 'O' ||
            c == 'u' || c == 'U') {
            vocales++;
        }
        i++;
    }

    printf("La frase tiene %d vocales.\n", vocales);

    while (getchar() != '\n'); // Limpiar buffer si quedó algo
    getchar(); // Esperar a que pulses Enter

    return 0;
}