#include <stdio.h>

int main() {
    int n;
    printf("Por favor ingrese el tamano para la figurita: ");
    scanf("%d", &n);
    printf("\n");

    int i = 0;
    do {
        int j = 0;
        do {
            if (i == 0 || i == n - 1 || j == 0 || j == n - 1) {
                // Alternar entre * y + según la suma de índices
                if ((i + j) % 2 == 0) {
                    printf("* ");
                } else {
                    printf("+ ");
                }
            } else {
                printf("  ");
            }
            j++;
        } while (j < n);
        printf("\n");
        i++;
    } while (i < n);

    getchar();
    getchar();
    return 0;
}