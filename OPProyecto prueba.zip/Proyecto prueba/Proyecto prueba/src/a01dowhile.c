#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_WORDS 10
#define BAR_LENGTH 15

int main() {
    char nombre[200];
    char porcentaje_str[200];
    char *palabras[MAX_WORDS];
    int porcentajes[MAX_WORDS];
    int num_palabras = 0, num_porcentajes = 0;

    // Leer nombre completo
    printf("Ingrese su nombre completo:\n");
    fgets(nombre, sizeof(nombre), stdin);
    nombre[strcspn(nombre, "\n")] = '\0';

    // Separar palabras con do-while
    char *token = strtok(nombre, " ");
    if (token != NULL) {
        do {
            palabras[num_palabras++] = token;
            token = strtok(NULL, " ");
        } while (token != NULL && num_palabras < MAX_WORDS);
    }

    // Leer los porcentajes
    printf("Ingrese el porcentaje de carga (uno por palabra, separados por espacio):\n");
    fgets(porcentaje_str, sizeof(porcentaje_str), stdin);
    porcentaje_str[strcspn(porcentaje_str, "\n")] = '\0';

    // Separar porcentajes con do-while
    token = strtok(porcentaje_str, " ");
    if (token != NULL) {
        do {
            porcentajes[num_porcentajes++] = atoi(token);
            token = strtok(NULL, " ");
        } while (token != NULL && num_porcentajes < MAX_WORDS);
    }

    // Validar cantidad
    if (num_porcentajes != num_palabras) {
        printf("\n❌ Error: Ingresaste %d palabras y %d porcentajes.\n", num_palabras, num_porcentajes);
        return 1;
    }

    // Mostrar nombre
    printf("\nNombre ingresado: ");
    int i = 0;
    if (num_palabras > 0) {
        do {
            printf("%s ", palabras[i++]);
        } while (i < num_palabras);
    }
    printf("\n\n");

    // Mostrar barras
    i = 0;
    if (num_palabras > 0) {
        do {
            int porcentaje = porcentajes[i];
            int barra = (porcentaje * BAR_LENGTH) / 100;

            printf("[");
            int j = 0;
            if (BAR_LENGTH > 0) {
                do {
                    if (j < barra - 1) printf("=");
                    else if (j == barra - 1) printf(">");
                    else printf(" ");
                    j++;
                } while (j < BAR_LENGTH);
            }

            printf("] %3d%% ", porcentaje);

            int mostrar = (strlen(palabras[i]) * porcentaje) / 100;
            j = 0;
            if (mostrar > 0) {
                do {
                    printf("%c", palabras[i][j]);
                    j++;
                } while (j < mostrar);
            }

            printf("\n");
            i++;
        } while (i < num_palabras);
    }

    // Esperar enter para cerrar
    printf("\nPresiona Enter para salir...");
    getchar();
    getchar();

    return 0;
}