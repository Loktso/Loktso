#include <stdio.h>

int main() {
    char frase[1000], invertida[1000];
    int longitud = 0;

    printf("Ingrese una frase: ");
    fgets(frase, sizeof(frase), stdin);

    // Obtener longitud sin contar '\n'
    while (frase[longitud] != '\0' && frase[longitud] != '\n') {
        longitud++;
    }

    int i = longitud - 1;
    int j = 0;

    while (i >= 0) {
        char c = frase[i];

        // Vocales se mantienen minúsculas
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
            c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
            if (c >= 'A' && c <= 'Z') {
                c += 32; // pasar a minúscula
            }
        }
        // Consonantes minúsculas pasan a mayúscula
        else if (c >= 'a' && c <= 'z') {
            c -= 32;
        }

        invertida[j++] = c;
        i--;
    }

    invertida[j] = '\0';

    printf("Salida: %s\n", invertida);

    while (getchar() != '\n'); // limpiar buffer
    getchar();

    return 0;
}