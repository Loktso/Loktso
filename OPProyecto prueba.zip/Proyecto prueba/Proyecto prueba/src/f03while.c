#include <stdio.h>

int main() {
    int n;
    printf("Ingrese el tamano del triangulo: ");
    scanf("%d", &n);
    printf("\n");

    int i = 1;
    while (i <= n) {
        int j = 1;
        while (j <= i) {
            printf("* ");
            j++;
        }
        printf("\n");
        i++;
    }

    getchar();
    getchar();
    return 0;
}