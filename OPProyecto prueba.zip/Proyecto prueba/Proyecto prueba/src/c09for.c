#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char frase[200];
    printf("Ingresa una frase: ");

    if (fgets(frase, sizeof(frase), stdin) == NULL) {
        printf("Error al leer la frase.\n");
        return 1;
    }

    frase[strcspn(frase, "\n")] = 0;

    for (int i = 0; frase[i] != '\0'; i++) {
        if (frase[i] == ' ') {
            putchar(' ');
        } else {
            if (i % 2 == 0)
                putchar(toupper(frase[i]));
            else
                putchar(tolower(frase[i]));
        }
    }

    printf("\n");

    getchar(); // Evita que la ventana se cierre de inmediato
    return 0;
}