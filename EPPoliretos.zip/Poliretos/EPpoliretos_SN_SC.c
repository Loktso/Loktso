#include <stdio.h>
#include <ctype.h>
#include <math.h>

void epEncabezado() {
    printf("Grupo 5: Ramdons del GR1CC ");
    printf("Integrantes: ");
    printf("1. PEN-A ERICK ");
    printf("2. OROZCO PABLO ");
    printf("3. NO APORTO ");
    printf("4. NO APORTO ");
    printf("5. NO APORTO ");
}

void epFibonacci(int t, int tipo) {
    int a = 0, b = 1, i = 0, temp;
    if (tipo == 1) {
        for (i = 0; i < t; i++) {
            printf("%d ", a);
            temp = a; a = b; b = temp + b;
        }
    } else if (tipo == 2) {
        while (i < t) {
            printf("%d ", a);
            temp = a; a = b; b = temp + b;
            i++;
        }
    } else {
        do {
            printf("%d ", a);
            temp = a; a = b; b = temp + b;
            i++;
        } while (i < t);
    }
    printf("\n");
}

void epParesImpares(int t, int tipo) {
    int i = 1;
    if (tipo == 1) {
        for (; i <= t; i++)
            printf("%d ", i % 2 ? i : 0);
    } else if (tipo == 2) {
        while (i <= t) {
            printf("%d ", i % 2 ? i : 0);
            i++;
        }
    } else {
        do {
            printf("%d ", i % 2 ? i : 0);
            i++;
        } while (i <= t);
    }
    printf("\n");
}

void epFracFibonacci(int t, int tipo, int denInicio) {
    int a = 0, b = 1, d = denInicio, i = 0, temp;
    if (tipo == 1) {
        for (; i < t; i++) {
            printf("%d/%d ", a, d);
            temp = a; a = b; b = temp + b; d += 2;
        }
    } else if (tipo == 2) {
        while (i < t) {
            printf("%d/%d ", a, d);
            temp = a; a = b; b = temp + b; d += 2;
            i++;
        }
    } else {
        do {
            printf("%d/%d ", a, d);
            temp = a; a = b; b = temp + b; d += 2;
            i++;
        } while (i < t);
    }
    printf("\n");
}

int epEsPrimo(int n) {
    if (n <= 1) return 0;
    for (int i = 2; i * i <= n; i++)
        if (n % i == 0) return 0;
    return 1;
}

void epPrimos(int t, int tipo) {
    int n = 2, c = 0;
    if (tipo == 1) {
        for (; c < t; n++) {
            if (epEsPrimo(n)) {
                printf("%d ", n);
                c++;
            }
        }
    } else if (tipo == 2) {
        while (c < t) {
            if (epEsPrimo(n)) {
                printf("%d ", n);
                c++;
            }
            n++;
        }
    } else {
        do {
            if (epEsPrimo(n)) {
                printf("%d ", n);
                c++;
            }
            n++;
        } while (c < t);
    }
    printf("\n");
}

void epCuadrados(int t, int tipo) {
    int i = 1;
    if (tipo == 1) {
        for (; i <= t; i++)
            printf("%d ", i * i);
    } else if (tipo == 2) {
        while (i <= t) {
            printf("%d ", i * i);
            i++;
        }
    } else {
        do {
            printf("%d ", i * i);
            i++;
        } while (i <= t);
    }
    printf("\n");
}

void epAritmetica(int t, int tipo, int inicio, int paso) {
    int v = inicio, i = 0;
    if (tipo == 1) {
        for (; i < t; i++, v += paso)
            printf("%d ", v);
    } else if (tipo == 2) {
        while (i < t) {
            printf("%d ", v);
            v += paso; i++;
        }
    } else {
        do {
            printf("%d ", v);
            v += paso; i++;
        } while (i < t);
    }
    printf("\n");
}

void epGeometrica(int t, int tipo, int inicio, int factor) {
    int v = inicio, i = 0;
    if (tipo == 1) {
        for (; i < t; i++, v *= factor)
            printf("%d ", v);
    } else if (tipo == 2) {
        while (i < t) {
            printf("%d ", v);
            v *= factor; i++;
        }
    } else {
        do {
            printf("%d ", v);
            v *= factor; i++;
        } while (i < t);
    }
    printf("\n");
}

void epTriangular(int t, int tipo) {
    int i = 1;
    if (tipo == 1) {
        for (; i <= t; i++)
            printf("%d ", i * (i + 1));
    } else if (tipo == 2) {
        while (i <= t) {
            printf("%d ", i * (i + 1));
            i++;
        }
    } else {
        do {
            printf("%d ", i * (i + 1));
            i++;
        } while (i <= t);
    }
    printf("\n");
}

void epAlternante(int t, int tipo) {
    int i = 0;
    if (tipo == 1) {
        for (; i < t; i++)
            printf("%c ", i % 2 ? '-' : '+');
    } else if (tipo == 2) {
        while (i < t) {
            printf("%c ", i % 2 ? '-' : '+');
            i++;
        }
    } else {
        do {
            printf("%c ", i % 2 ? '-' : '+');
            i++;
        } while (i < t);
    }
    printf("\n");
}

void epConcatena(int t, int tipo) {
    int i = 0;
    if (tipo == 1) {
        for (; i < t; i++) {
            for (int j = 0; j <= i; j++) printf("+");
            printf(" ");
        }
    } else if (tipo == 2) {
        while (i < t) {
            for (int j = 0; j <= i; j++) printf("+");
            printf(" "); i++;
        }
    } else {
        do {
            for (int j = 0; j <= i; j++) printf("+");
            printf(" "); i++;
        } while (i < t);
    }
    printf("\n");
}

void epTriangulo(int t, int tipo) {
    int a = 1, b = 1, temp, i = 0;
    if (tipo == 1) {
        for (; i < t; i++) {
            for (int j = 0; j < a; j++) printf("+");
            printf(" ");
            temp = a; a = b; b = temp + b;
        }
    } else if (tipo == 2) {
        while (i < t) {
            for (int j = 0; j < a; j++) printf("+");
            printf(" ");
            temp = a; a = b; b = temp + b;
            i++;
        }
    } else {
        do {
            for (int j = 0; j < a; j++) printf("+");
            printf(" ");
            temp = a; a = b; b = temp + b;
            i++;
        } while (i < t);
    }
    printf("\n");
}

void epAlternanteChars(int t, int tipo) {
    char chars[] = {'+', '-', '*', '/'};
    int i = 0;
    if (tipo == 1) {
        for (; i < t; i++)
            printf("%c ", chars[i % 4]);
    } else if (tipo == 2) {
        while (i < t) {
            printf("%c ", chars[i % 4]);
            i++;
        }
    } else {
        do {
            printf("%c ", chars[i % 4]);
            i++;
        } while (i < t);
    }
    printf("\n");
}

void epCaracteres(int t, int tipo) {
    char chars[] = {'\\', '|', '/', '-'};
    int i = 0;
    if (tipo == 1) {
        for (; i < t; i++)
            printf("%c ", chars[i % 4]);
    } else if (tipo == 2) {
        while (i < t) {
            printf("%c ", chars[i % 4]);
            i++;
        }
    } else {
        do {
            printf("%c ", chars[i % 4]);
            i++;
        } while (i < t);
    }
    printf("\n");
}

void epAlfabeto(int t, int tipo) {
    int i = 0;
    if (tipo == 1) {
        for (; i < t; i++)
            printf("%c ", 'a' + i);
    } else if (tipo == 2) {
        while (i < t) {
            printf("%c ", 'a' + i);
            i++;
        }
    } else {
        do {
            printf("%c ", 'a' + i);
            i++;
        } while (i < t);
    }
    printf("\n");
}

void epAlfabetoAlternante(int t, int tipo) {
    int i = 0;
    if (tipo == 1) {
        for (; i < t; i++)
            printf("%c ", i % 2 ? '+' : 'a' + i);
    } else if (tipo == 2) {
        while (i < t) {
            printf("%c ", i % 2 ? '+' : 'a' + i);
            i++;
        }
    } else {
        do {
            printf("%c ", i % 2 ? '+' : 'a' + i);
            i++;
        } while (i < t);
    }
    printf("\n");
}

void epRepeticion(int t, int tipo) {
    int i = 0;
    if (tipo == 1) {
        for (; i < t; i++) {
            for (int j = 0; j < (i + 1) * 2; j++) printf("%c", 'a' + i);
            printf(" ");
        }
    } else if (tipo == 2) {
        while (i < t) {
            for (int j = 0; j < (i + 1) * 2; j++) printf("%c", 'a' + i);
            printf(" "); i++;
        }
    } else {
        do {
            for (int j = 0; j < (i + 1) * 2; j++) printf("%c", 'a' + i);
            printf(" "); i++;
        } while (i < t);
    }
    printf("\n");
}

void epEscalera(int t, int tipo) {
    int i = 0;
    if (tipo == 1) {
        for (; i < t; i++) {
            for (int j = 0; j < i + 1; j++) printf("%c", 'a' + i);
            printf(" ");
        }
    } else if (tipo == 2) {
        while (i < t) {
            for (int j = 0; j < i + 1; j++) printf("%c", 'a' + i);
            printf(" "); i++;
        }
    } else {
        do {
            for (int j = 0; j < i + 1; j++) printf("%c", 'a' + i);
            printf(" "); i++;
        } while (i < t);
    }
    printf("\n");
}

int main() {
    int t;
    char entrada[10];
    epEncabezado();
    
    while (1) {
        printf("Terminos (numero positivo): ");
        scanf("%s", entrada);
        int valido = 1;
        for (int i = 0; entrada[i]; i++) {
            if (!isdigit(entrada[i])) {
                valido = 0;
                break;
            }
        }
        if (valido) {
            t = atoi(entrada);
            if (t > 0) break;
            printf("Solo positivos! ");
        } else {
            printf("Solo numeros! ");
            while (getchar() != '\n');
        }
    }

    printf(" SERIES NUMERICAS ");
    printf("S1 DE Fibonacci ");
    epFibonacci(t, 1); epFibonacci(t, 2); epFibonacci(t, 3);
    printf("S2 DE Pares/Impares ");
    epParesImpares(t, 1); epParesImpares(t, 2); epParesImpares(t, 3);
    printf("S3 DE Fraccion Fibonacci ");
    epFracFibonacci(t, 1, 1); epFracFibonacci(t, 2, 1); epFracFibonacci(t, 3, 1);
    printf("S4 DE Fraccion Fibonacci 2 ");
    epFracFibonacci(t, 1, 2); epFracFibonacci(t, 2, 2); epFracFibonacci(t, 3, 2);
    printf("S5 DE Primos ");
    epPrimos(t, 1); epPrimos(t, 2); epPrimos(t, 3);
    printf("S6 DE Cuadrados ");
    epCuadrados(t, 1); epCuadrados(t, 2); epCuadrados(t, 3);
    printf("S7 DE Aritmetica ");
    epAritmetica(t, 1, 1, 3); epAritmetica(t, 2, 1, 3); epAritmetica(t, 3, 1, 3);
    printf("S8 DE Aritmetica 2 ");
    epAritmetica(t, 1, 3, 5); epAritmetica(t, 2, 3, 5); epAritmetica(t, 3, 3, 5);
    printf("S9 DE Geometrica ");
    epGeometrica(t, 1, 2, 2); epGeometrica(t, 2, 2, 2); epGeometrica(t, 3, 2, 2);
    printf("S10 DE Geometrica 2 ");
    epGeometrica(t, 1, 3, 3); epGeometrica(t, 2, 3, 3); epGeometrica(t, 3, 3, 3);
    printf("S12 DE Triangular ");
    epTriangular(t, 1); epTriangular(t, 2); epTriangular(t, 3);
    printf(" SERIES DE CARACTERES ");
    printf("S1 DE Alternante ");
    epAlternante(t, 1); epAlternante(t, 2); epAlternante(t, 3);
    printf("S2 DE Concatena ");
    epConcatena(t, 1); epConcatena(t, 2); epConcatena(t, 3);
    printf("S3 DE Triangulo ");
    epTriangulo(t, 1); epTriangulo(t, 2); epTriangulo(t, 3);
    printf("S4 DE Alternante Chars ");
    epAlternanteChars(t, 1); epAlternanteChars(t, 2); epAlternanteChars(t, 3);
    printf("S5 DE Caracteres ");
    epCaracteres(t, 1); epCaracteres(t, 2); epCaracteres(t, 3);
    printf("S6 DE Alfabeto ");
    epAlfabeto(t, 1); epAlfabeto(t, 2); epAlfabeto(t, 3);
    printf("S6 DE Alfabeto Alternante ");
    epAlfabetoAlternante(t, 1); epAlfabetoAlternante(t, 2); epAlfabetoAlternante(t, 3);
    printf("S7 DE Repeticion ");
    epRepeticion(t, 1); epRepeticion(t, 2); epRepeticion(t, 3);
    printf("S8 DE Escalera ");
    epEscalera(t, 1); epEscalera(t, 2); epEscalera(t, 3);
    
    return 0;
}